

import time,secp256k1,multiprocessing
import sympy,random

def is_prime(n):
    return sympy.isprime(n)

h160nf = {66: '20d45a6a762535700ce9e0b216e31994335db8a5', 67: '739437bb3dd6d1983e66629c5f08c70e52769371', 68: 'e0b8a2baee1b77fc703455f39d51477451fc8cfc', 69: '61eb8a50c86b0584bb727dd65bed8d2400d6d5aa', 71: 'f6f5431d25bbf7b12e8add9af5e3475c44a0a5b8', 72: 'bf7413e8df4e7a34ce9dc13e2f2648783ec54adb', 73: '105b7f253f0ebd7843adaebbd805c944bfb863e4', 74: '9f1adb20baeacc38b3f49f3df6906a0e48f2df3d', 76: '86f9fea5cdecf033161dd2f8f8560768ae0a6d14', 77: '783c138ac81f6a52398564bb17455576e8525b29', 78: '35003c3ef8759c92092f8488fca59a042859018c', 79: '67671d5490c272e3ab7ddd34030d587738df33da', 81: '351e605fac813965951ba433b7c2956bf8ad95ce', 82: '20d28d4e87543947c7e4913bcdceaa16e2f8f061', 83: '24cef184714bbd030833904f5265c9c3e12a95a2', 84: '7c99ce73e19f9fbfcce4825ae88261e2b0b0b040', 86: 'c60111ed3d63b49665747b0e31eb382da5193535', 87: 'fbc708d671c03e26661b9c08f77598a529858b5e', 88: '38a968fdfb457654c51bcfc4f9174d6ee487bb41', 89: '5c3862203d1e44ab3af441503e22db97b1c5097e', 91: '9978f61b92d16c5f1a463a0995df70da1f7a7d2a', 92: '6534b31208fe6e100d29f9c9c75aac8bf06fbb38', 93: '463013cd41279f2fd0c31d0a16db3972bfffac8d', 94: 'c6927a00970d0165327d0a6db7950f05720c295c', 96: '2da63cbd251d23c7b633cb287c09e6cf888b3fe4', 97: '578d94dc6f40fff35f91f6fba9b71c46b361dff2', 98: '7eefddd979a1d6bb6f29757a1f463579770ba566', 99: 'c01bf430a97cbcdaedddba87ef4ea21c456cebdb', 101: '7c1a77205c03b9909663b2034faa0b544e6bc96b', 102: 'f72b812932f6d7102233971d65cec0a22b89e136', 103: '695fd6dcf33f47166b25de968b2932b351b0afc4', 104: '93022af9a38f3ebb0c3f15dd1c83f8fadaf64e74', 106: '505aaa63a5e209dfb90cee683a8e227a8c278e47', 107: '2e644e46b042ffa86da35c54d7275f1abe6d4911', 108: 'b166c44f12c7fc565f37ff6288ee64e0f0ec9a0b', 109: 'aeb0a0197442d4ade8ef41442d557b0e22b85ac0', 111: '4cfc43fe12a330c8164251e38c0c0c3c84cf86f6', 112: '4e81efec43c5195aeca0e3877664330418b8e48e', 113: 'ed673389e4b12925316f9166d56d701829e53cf8', 114: '42773005f9594cd16b10985d428418acb7f352ec', 116: 'e3f381c34a20da049779b44cae0417c7fb2898d0', 117: 'c97f9591e28687be1c4d972e25be7c372a3221b4', 118: 'f4a4e1c11a5bbbd2fc139d221825407c66e0b8b4', 119: 'ae6804b35c82f47f8b0a42d8c5e514fe5ef0a883', 120: '4b46e10a541aeec6be3fac709c256fb7da69308e', 121: 'a6e4818537e42f7b3f021daa810367dad4dda16f', 122: 'e263b62ea294b9650615a13b926e75944c823990', 123: '7fa4515066ba6905f894b2078f9af7b1379169cf', 124: '75f74467ce7214f1767406d5ed12012aa523c48e', 125: 'f7079256aa027dc437cbb539f955472416725fc8', 126: '683ea8a1ef06eada90556017d44323b5c04e00f1', 127: 'a58708aa98ad35c889bb36d8049bf9e9cacfd02a', 128: 'e170ef514689d7230da362a0c121a07723550512', 129: 'ba4c2748360a6b66263e11d1dc8658463ca5ff18', 130: 'a24922852051a9002ebf4c864a55acb75bb4cf75', 131: '41b4b36a6c036568972380177eca2916cacd71de', 132: 'cecd3ca4319651bd3afd1e23ab66e111ed38d16d', 133: '014e15e4ea6da460cc7835e262676baa37988e4f', 134: '17a5ebfaf62e73f149e33ba674836801f13a80b9', 135: '3b6f58a75a54bfd85d1bc6c51180fdc732992326', 136: '05257be4b57ee43fc09762d5d3a9ad4a6e1a0364', 137: '3482f8986e13c018692053a784481c63a3554c9c', 138: '692a8e583866fc9056f5c61a45969fb9d868a08c', 139: 'a45dae9cd5d3fde21e5aa9a95367d107267b3b8a', 140: 'ffbb35a7bb9bbe16c1aa2534f7ff11d59c8e3d1a', 141: '7af50f73fd580f1713af3a6f9c5de49643ec6fc6', 142: '2fcea55e6d027a2ba7c7ebe95eedf47766730fe2', 143: '19ed3e03d19ddcedd5fa86543be820b3a7951650', 144: 'ed87120066e244ff5331d5f8625873d7a3acc39c', 145: '5abf369388deb8072741b4eb43ef10fa9388a729', 146: 'dca7ebfb78ce21884300f133d89244bc4b1b756f', 147: '5318b9d7fcc93873f768725eb68ba2c924bb07ee', 148: 'a3e3612e586fd206efb8eee6ccd58318e182829a', 149: '7e827e3b90da24c2a15f7b67e3bbece39955a5d0', 150: 'e08c4d3bc9cf2b3e2cb88de2bfaa4fe8c7aa3f24', 151: '1a4fb632f0de0c53a0a31d57f840a19e56c645ee', 152: 'da56cd815fa2f0d6a4ce6d25ed7b1a01d9f9bc6b', 153: '4ccf94a1b0efd63cddeee0ef5eee5ebe720cfcbf', 154: 'edd2e206825fa8949d1304cd82c08d64b222f2eb', 155: '6b8b7830f73c5bf9e8beb9f161ad82b3bde992e4', 156: '9ea3f29aaedf7da10b1488934c50a39e271b0b64', 157: '242d790e5a168043c76f0539fd894b73ee67b3b3', 158: '628dacebb0faa7f81670e174ca4c8a95a7e37029', 159: '2ac1295b4e54b3f15bb0a99f84018d2082495645', 160: 'e84818e1bf7f699aa6e28ef9edfb582099099292'}
h160f = {1: '751e76e8199196d454941c45d1b3a323f1433bd6', 2: '7dd65592d0ab2fe0d0257d571abf032cd9db93dc', 3: '5dedfbf9ea599dd4e3ca6a80b333c472fd0b3f69', 4: '9652d86bedf43ad264362e6e6eba6eb764508127', 5: '8f9dff39a81ee4abcbad2ad8bafff090415a2be8', 6: 'f93ec34e9e34a8f8ff7d600cdad83047b1bcb45c', 7: 'e2192e8a7dd8dd1c88321959b477968b941aa973', 8: 'dce76b2613052ea012204404a97b3c25eac31715', 9: '7d0f6c64afb419bbd7e971e943d7404b0e0daab4', 10: 'd7729816650e581d7462d52ad6f732da0e2ec93b', 11: 'f8c698da3164ef8fa4258692d118cc9a902c5acc', 12: '85a1f9ba4da24c24e582d9b891dacbd1b043f971', 13: 'f932d0188616c964416b91fb9cf76ba9790a921e', 14: '97f9281a1383879d72ac52a6a3e9e8b9a4a4f655', 15: 'fe7c45126731f7384640b0b0045fd40bac72e2a2', 16: '7025b4efb3ff42eb4d6d71fab6b53b4f4967e3dd', 17: 'b67cb6edeabc0c8b927c9ea327628e7aa63e2d52', 18: 'ad1e852b08eba53df306ec9daa8c643426953f94', 19: 'ebfbe6819fcdebab061732ce91df7d586a037dee', 20: 'b907c3a2a3b27789dfb509b730dd47703c272868', 21: '29a78213caa9eea824acf08022ab9dfc83414f56', 22: '7ff45303774ef7a52fffd8011981034b258cb86b', 23: 'd0a79df189fe1ad5c306cc70497b358415da579e', 24: '0959e80121f36aea13b3bad361c15dac26189e2f', 25: '2f396b29b27324300d0c59b17c3abc1835bd3dbb', 26: 'bfebb73562d4541b32a02ba664d140b5a574792f', 27: '0c7aaf6caa7e5424b63d317f0f8f1f9fa40d5560', 28: '1306b9e4ff56513a476841bac7ba48d69516b1da', 29: '5a416cc9148f4a377b672c8ae5d3287adaafadec', 30: 'd39c4704664e1deb76c9331e637564c257d68a08', 31: 'd805f6f251f7479ebd853b3d0f4b9b2656d92f1d', 32: '9e42601eeaedc244e15f17375adb0e2cd08efdc9', 33: '4e15e5189752d1eaf444dfd6bff399feb0443977', 34: 'f6d67d7983bf70450f295c9cb828daab265f1bfa', 35: 'f6d8ce225ffbdecec170f8298c3fc28ae686df25', 36: '74b1e012be1521e5d8d75e745a26ced845ea3d37', 37: '28c30fb9118ed1da72e7c4f89c0164756e8a021d', 38: 'b190e2d40cfdeee2cee072954a2be89e7ba39364', 39: '0b304f2a79a027270276533fe1ed4eff30910876', 40: '95a156cd21b4a69de969eb6716864f4c8b82a82a', 41: 'd1562eb37357f9e6fc41cb2359f4d3eda4032329', 42: '8efb85f9c5b5db2d55973a04128dc7510075ae23', 43: 'f92044c7924e5525c61207972c253c9fc9f086f7', 44: '80df54e1f612f2fc5bdc05c9d21a83aa8d20791e', 45: 'f0225bfc68a6e17e87cd8b5e60ae3be18f120753', 46: '9a012260d01c5113df66c8a8438c9f7a1e3d5dac', 47: 'f828005d41b0f4fed4c8dca3b06011072cfb07d4', 48: '8661cb56d9df0a61f01328b55af7e56a3fe7a2b2', 49: '0d2f533966c6578e1111978ca698f8add7fffdf3', 50: 'de081b76f840e462fa2cdf360173dfaf4a976a47', 51: 'ef6419cffd7fad7027994354eb8efae223c2dbe7', 52: '36af659edbe94453f6344e920d143f1778653ae7', 53: '2f4870ef54fa4b048c1365d42594cc7d3d269551', 54: 'cb66763cf7fde659869ae7f06884d9a0f879a092', 55: 'db53d9bbd1f3a83b094eeca7dd970bd85b492fa2', 56: '48214c5969ae9f43f75070cea1e2cb41d5bdcccd', 57: '328660ef43f66abe2653fa178452a5dfc594c2a1', 58: '8c2a6071f89c90c4dab5ab295d7729d1b54ea60f', 59: 'b14ed3146f5b2c9bde1703deae9ef33af8110210', 60: 'cdf8e5c7503a9d22642e3ecfc87817672787b9c5', 61: '68133e19b2dfb9034edf9830a200cfdf38c90cbd', 62: 'e26646db84b0602f32b34b5a62ca3cae1f91b779', 63: 'ef58afb697b094423ce90721fbb19a359ef7c50e', 64: '3ee4133d991f52fdf6a25c9834e0745ac74248a4', 65: '52e763a7ddc1aa4fa811578c491c1bc7fd570137', 70: '5db8cda53a6a002db10365967d7f85d19e171b10', 75: 'badf8b0d34289e679ec65c6c61d3a974353be5cf', 80: '6fe5a36eef0684af0b91f3b6cfc972d68c4f6fab', 85: 'cd03c1e6268ce9b89e3c3eeab8d0f1b6e8cac281', 90: 'd06b6e206691295ec345782d7ea0686969d8674b', 95: '5ed822125365274262191d2b77e88d436dd56d88', 100: 'c7a7b23f6bd98b8aaf527beb724dda9460b1bc6e', 105: '7c957db6fdd0733bb83bc6d6d747711263ba50b0', 110: '0e5f3c406397442996825fd395543514fd06f207', 115: 'ea0f2b7576bd098921fce9bfebe37f6383e639a4'}

targets_nf = set([bytes.fromhex(h160nf[h]) for h in h160nf])
targets_f = set([bytes.fromhex(h160f[h]) for h in h160f])
ord_found = set()
ordx = {bytes.fromhex(h160f[h]):h for h in h160f}
ordx.update({bytes.fromhex(h160nf[h]):h for h in h160nf})

def min_range(num):
    rng = 255
    while abs(num) < 2**rng:
        rng -= 1
    return rng+1

def dance(a,b, step=1):

    while a != b:
        yield a, b, random.randint(a+1, b-1)
        a += step
        b -= step

"""for a in dance(2**10,2**12):
    print(a)
time.sleep(9)"""

def process(args):
    global ord_found,targets_f,targets_nf,ordx

    prime_start,target_range,initial_factor,max_factor = args

    for a in range(max_factor,initial_factor,-1):
    #for stuff in dance(initial_factor,max_factor):
        #print(stuff)

        k = prime_start*a
        #print(hex(k)[2:])

        if not ( 2**(target_range-1) < k < 2**(target_range) ) :
            #print("something is wrong",k,min_range(k),target_range)
            continue
        
        h = secp256k1.privatekey_to_h160(0,True,k)
        if h in targets_f:
            ordd = ordx[h]
            if ordd not in ord_found:
                print("reveal",k,ordd)
                print("OMG",secp256k1.btc_pvk_to_wif(k,True))
                # save to file
                with open("found-mj.txt","a") as f:
                    f.write(f"{secp256k1.btc_pvk_to_wif(k,True)} {k} {ordd}\n")

                ord_found.add(ordd)
                break
                #not_finish = False
            
        if h in targets_nf:
            ordd = ordx[h]
            if ordd not in ord_found:
                print("found",k,ordd)
                print("OMG",secp256k1.btc_pvk_to_wif(k,True))
                # save to file
                with open("found-mj.txt","a") as f:
                    f.write(f"{secp256k1.btc_pvk_to_wif(k,True)} {k} {ordd}\n")
                ord_found.add(ordd)
                break

    #print(prime_start)
                


if __name__ == "__main__":
    import simplejson as json

    prime_start = 34537
    prime_end   = 16181749866767
    prime_start = prime_end
    prime_start = 277454695180914278445801611

    # test 
    prime_start = 795565215019
    prime_end = 54837982408409807
    prime_end = 180987396728623
    prime_end = 180987396692819
    prime_end = 180987395950061
    prime_end = 54837982228652809 
    prime_end = 15117518732539
    #prime_end = sympy.randprime(2**50, 2**60) # 919625219753424187
    #prime_end = 16181749866787

    #prime_end = 277454695180914278445801611
    primes = [54837982408409807, 19543033591421617, 180987396728603, 79066817083867, 16181749866767, 15117518732539, 
              5571097669559, 4902742941037, 3046807857407, 795565215019, 570501825841, 268491108091, 183994400687, 63402269789,
              20073028259, 11113907731, 6683437373, 5452682773, 2201090527, 1499107913, 1390232159, 240750329, 235487611, 117755873,
              96696499, 75601117, 62922991, 50847529, 41847781, 36678953, 18668011, 14359547, 5533739, 5495543, 4740787, 3247603, 2783789,
              2511323, 2413909, 1760491, 1053863, 1002377, 867829, 805153, 556519, 458069, 408229, 313561, 260047, 255473, 254491, 241313, 
              189851, 173933, 153001, 138493, 138319, 120929, 107999, 88261, 76123, 60037, 42379, 34537, 25229, 22409, 22039, 12211, 8527, 
              7477, 7019, 5839, 5639, 4909, 3761, 3637, 3253, 3109, 3001, 2903, 2687, 2477, 2383, 1931, 1733, 1663, 1409, 811, 769, 751, 659, 
              647, 643, 587, 401, 307, 269, 257, 251, 197, 193, 179, 167, 163, 157, 131, 103, 101, 89, 83, 71, 67, 59, 53, 47, 43, 41, 31, 29, 23, 19, 17, 13, 11, 7, 5, 3, 2]
    
    for loop in range(45):
        for fact in list(primes):
            np = fact * 2 
            np =sympy.nextprime(np)
            if np not in primes and min_range(np) <= 37:
                primes.append(np)

    #primes.sort(reverse=True)
    #print(primes)
    print(len(primes))
    #time.sleep(99)



    #print(primes)

    #target_ranges  = list(range(66,66+1))#[66, 67, 68, 69]
    #target_ranges = list(range(40,41+1))
    target_ranges = [66, 67, 68, 69, 71, 72, 73, 74, 76, 77, 78, 79, 81, 82, 83, 84, 86, 87, 88, 89, 91, 92, 93, 94, 96, 97, 98, 99, 101, 102, 103, 104, 106, 107, 108, 109, 111, 112, 113, 114, 116, 117, 118, 119, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 146, 147, 148, 149, 150]
    
    work = []

    proof = set()
    import random
    
    #while len(work) < 10**6:
    while True:
        while len(work) <= 6400:

            '''for target_range in target_ranges:
                initial_factor = 2**(target_range-1) // prime_start
                max_factor = 2**target_range // prime_start
                print(target_range,prime_start,initial_factor,max_factor,max_factor-initial_factor,min_range(max_factor-initial_factor))
                work.append((prime_start,target_range,initial_factor,max_factor))'''

            for target_range in target_ranges:

                for prime_end in list(primes):
                    initial_factor = 2**(target_range-1) // prime_end
                    max_factor = 2**target_range // prime_end
                    if 20 < min_range(max_factor-initial_factor) or 5 > min_range(max_factor-initial_factor):
                        continue
                    #print(target_range,prime_end,min_range(prime_end),initial_factor,max_factor,max_factor-initial_factor,min_range(max_factor-initial_factor),len(work))
                    work.append((prime_end,target_range,initial_factor,max_factor))

                    primes.remove(prime_end)
                    primes.append(sympy.prevprime(prime_end))
            
            #print(primes)

            #prime_start = sympy.prevprime(prime_start)
            """prime_start = sympy.nextprime(prime_start)
            try:

                #prime_end = sympy.nextprime(prime_end)
                prime_end = sympy.prevprime(prime_end)
            except:
                print("eerrr")
                break"""

        
        random.shuffle(work)
        p = multiprocessing.Pool()
        p.map(process, work)
        p.close()
        #print(prime_start,prime_end)
        #print(prime_end)
        json.dump(primes,open("primes.json","w"),indent=4)

        work = []


        """for item in work:

            prime = item[0]
            for a in range(item[2],item[3]):
                k = prime*a
                if k in proof:
                    print(k,"duplicate omg")
                proof.add(prime*a)"""

        
        # sort_work by step 
        """work.sort(key=lambda x: x[0], reverse=True)

        p = multiprocessing.Pool()
        p.map(process, work)
        p.close()"""